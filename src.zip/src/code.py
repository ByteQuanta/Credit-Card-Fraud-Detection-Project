# ---------------------------------------------------------------
# 2️⃣ Importing Data
# ---------------------------------------------------------------
import pandas as pd
from sqlalchemy import create_engine
from dotenv import load_dotenv
import os

# .env dosyasını yükle
load_dotenv()

# Ortam değişkenlerinden bilgileri al
DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_HOST = os.getenv("DB_HOST")
DB_NAME = os.getenv("DB_NAME")

# Güvenli bağlantı oluştur
engine = create_engine(
    f"mysql+mysqlconnector://{DB_USER}:{DB_PASS}@{DB_HOST}/{DB_NAME}"
)

# Tüm tabloyu DataFrame olarak çek
TABLE_NAME = "your_table"  # ← sadece tablo adını buradan değiştir
df = pd.read_sql(f"SELECT * FROM {TABLE_NAME}", con=engine)

# Veri boyutunu kontrol
print(df.shape)
# Örnek veri
print(df.head())

# ---------------------------------------------------------------
# 3️⃣ Summary of Missing Data
# ---------------------------------------------------------------
missing_summary = df.isnull().sum().sort_values(ascending=False)
missing_percent = (df.isnull().sum() / len(df) * 100).sort_values(ascending=False)
missing_df = pd.concat([missing_summary, missing_percent], axis=1, keys=['Missing Count', 'Missing %'])
print("Missing Data Summary:\n", missing_df[missing_df['Missing Count'] > 0])

# ---------------------------------------------------------------
# 4️⃣ Inspect the Data's Variables
# ---------------------------------------------------------------
df.head()

df.info()

df.describe()

# Tekrar eden ID kontrolü (varsa)
if 'id' in df.columns:
    print("Duplicated id count:", df['id'].duplicated().sum())

# Fraud oranı (Class) sütununa göre
print("Overall fraud rate:", df['Class'].mean())

# Fraud oranı V1–V28 veya Amount bazlı (basit grup örneği)
# Örnek: Amount’a göre fraud oranı
# Orijinal df'i korumak için kopya oluştur
df_copy = df.copy()

# Amount segmentlerini kopya üzerinde oluştur
df_copy['amount_range'] = pd.cut(df_copy['Amount'],
                                 bins=[0, 10, 100, 1000, 5000, df_copy['Amount'].max()],
                                 labels=['<10', '10-100', '100-1000', '1000-5000', '>5000'])

# Fraud oranını Amount segmentlerine göre incele
print(df_copy.groupby('amount_range')['Class'].mean())

import matplotlib.pyplot as plt
import seaborn as sns

# df_copy üzerinden işlemler
numeric_cols = ['Time', 'Amount'] + [f'V{i}' for i in range(1,29)]

# Histogramlar
df_copy[numeric_cols].hist(figsize=(16,12), bins=30)
plt.tight_layout()
plt.show()

# Korelasyon ısı haritası
plt.figure(figsize=(12,10))
sns.heatmap(df_copy.corr(numeric_only=True), annot=False, cmap='coolwarm')
plt.title("Correlation Heatmap")
plt.show()

# Fraud oranı kategorik bazlı (Amount segmenti)
sns.barplot(x='amount_range', y='Class', data=df_copy)
plt.title("Fraud Rate by Amount Range")
plt.show()

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import optuna
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import RobustScaler
from sklearn.pipeline import Pipeline

# ---------------------------------------------------------------
# 5️⃣ Feature Importance Analysis (Fraud Dataset) – Hızlı Ayarlı
# ---------------------------------------------------------------

# === 1. Prepare Data ===
X = df.drop(['Class'], axis=1)  # Features
y = df['Class']                  # Target

# 🚨 Train-test split
X_train_raw, X_test_raw, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# === 2. Define Optuna objective ===
def objective_rf(trial):
    n_estimators = trial.suggest_int("n_estimators", 50, 100, step=25)  # 50-100
    max_depth = trial.suggest_int("max_depth", 3, 20)                     # 3-20
    min_samples_split = trial.suggest_int("min_samples_split", 2, 10)    # 2-10
    min_samples_leaf = trial.suggest_int("min_samples_leaf", 1, 5)       # 1-5
    max_features = trial.suggest_categorical("max_features", ["sqrt", "log2", None])
    criterion = trial.suggest_categorical("criterion", ["gini", "entropy"])
    class_weight = trial.suggest_categorical("class_weight", [None, "balanced"])

    pipeline = Pipeline([
        ("scaler", RobustScaler()),
        ("clf", RandomForestClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            min_samples_split=min_samples_split,
            min_samples_leaf=min_samples_leaf,
            max_features=max_features,
            criterion=criterion,
            class_weight=class_weight,
            random_state=42,
            n_jobs=-1
        ))
    ])

    # 3-fold CV ile f1 skoru
    scores = cross_val_score(pipeline, X_train_raw, y_train, cv=3, scoring="f1", n_jobs=-1)
    return scores.mean()

# === 3. Optimize (Optuna 10 trial) ===
study_rf = optuna.create_study(direction="maximize")
study_rf.optimize(objective_rf, n_trials=10)  # 10 trial ile hız kazancı

best_params = study_rf.best_params
print("Best Parameters:", best_params)

# === 4. Nested CV Feature Importance (3-fold) ===
kf = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
importances_list = []

fold = 1
for train_idx, val_idx in kf.split(X_train_raw, y_train):
    X_tr, X_val = X_train_raw.iloc[train_idx], X_train_raw.iloc[val_idx]
    y_tr, y_val = y_train.iloc[train_idx], y_train.iloc[val_idx]
    
    model_cv = RandomForestClassifier(**best_params, random_state=42, n_jobs=-1)
    model_cv.fit(X_tr, y_tr)
    
    importances_list.append(model_cv.feature_importances_)
    print(f"Fold {fold} done.")
    fold += 1

# 📊 Mean of the Importance
mean_importance = np.mean(importances_list, axis=0)
importances_nestedcv = pd.Series(mean_importance, index=X_train_raw.columns).sort_values(ascending=False)

# Visualization
plt.figure(figsize=(10, 6))
importances_nestedcv.head(20).sort_values().plot(kind="barh", color="darkorange")
plt.title("Feature Importances (Nested CV – 3-Fold Mean, Hızlı)")
plt.xlabel("Mean Importance")
plt.ylabel("Feature")
plt.tight_layout()
plt.show()

# 📋 Top 10 important features
print("\nTop 10 Important Features (Nested CV Mean):")
print(importances_nestedcv.head(10))

# ---------------------------------------------------------------
# 7️⃣ Model explainability with SHAP (Random Forest)
# ---------------------------------------------------------------
import shap

# Train final optimized Random Forest model
model_optimized = RandomForestClassifier(**best_params, random_state=42, n_jobs=-1)
model_optimized.fit(X_train_raw, y_train)

# sample from raw training data (same structure as model training)
X_sample = X_train_raw.sample(n=min(1000, len(X_train_raw)), random_state=42)

# create explainer (TreeExplainer supports sklearn RF)
explainer = shap.TreeExplainer(model_optimized)

# get SHAP values
shap_values = explainer.shap_values(X_sample)

# handle list vs array output (binary / multi-class)
if isinstance(shap_values, list):
    shap_values_to_plot = shap_values[1]  # class 1 (fraud)
else:
    shap_values_to_plot = shap_values

# SHAP summary plot
shap.summary_plot(shap_values_to_plot, X_sample)

# ======================================
# 2️⃣ Define Objective for Optuna + CV
# ======================================
def objective(trial, X, y):
    import xgboost as xgb
    from sklearn.metrics import roc_auc_score
    from sklearn.model_selection import StratifiedKFold
    import numpy as np

    params = {
        "objective": "binary:logistic",
        "eval_metric": "auc",
        "eta": trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
        "max_depth": trial.suggest_int("max_depth", 3, 10),
        "subsample": trial.suggest_float("subsample", 0.6, 1.0),
        "colsample_bytree": trial.suggest_float("colsample_bytree", 0.6, 1.0),
        "lambda": trial.suggest_float("lambda", 1e-3, 10.0, log=True),
        "alpha": trial.suggest_float("alpha", 1e-3, 10.0, log=True),
        "verbosity": 0,
        "seed": 42,
        "nthread": -1
    }

    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    aucs = []

    X_np, y_np = X.values, y.values

    for train_idx, valid_idx in skf.split(X_np, y_np):
        X_train, X_valid = X_np[train_idx], X_np[valid_idx]
        y_train, y_valid = y_np[train_idx], y_np[valid_idx]

        dtrain = xgb.DMatrix(X_train, label=y_train)
        dvalid = xgb.DMatrix(X_valid, label=y_valid)

        model = xgb.train(
            params,
            dtrain,
            num_boost_round=200,
            evals=[(dvalid, "validation")],
            early_stopping_rounds=20,
            verbose_eval=False
        )

        preds = model.predict(dvalid)
        auc = roc_auc_score(y_valid, preds)
        aucs.append(auc)

    return np.mean(aucs)

# ======================================
# 3️⃣ Run Optuna Study (with Logging)
# ======================================
def tune_hyperparameters(X, y):
    import optuna
    import os

    study = optuna.create_study(
        direction="maximize",
        study_name="xgb_churn_opt",
        pruner=optuna.pruners.MedianPruner(n_warmup_steps=5)
    )

    study.optimize(lambda trial: objective(trial, X, y), n_trials=30, timeout=900)

    os.makedirs("models", exist_ok=True)
    study.trials_dataframe().to_csv("models/optuna_trials_log.csv", index=False)

    print("✅ Best AUC:", study.best_trial.value)
    print("✅ Best Params:", study.best_trial.params)

    return study.best_trial.params

# ======================================
# 4️⃣ Train Final Model
# ======================================
def train_final_model(X_train, y_train, best_params):
    import xgboost as xgb
    model = xgb.XGBClassifier(
        **best_params,
        random_state=42,
        eval_metric="auc"
    )
    model.fit(X_train, y_train)
    return model



# ======================================
# 5️⃣ Explain Model with SHAP (Aligned)
# ======================================
def explain_model(model, X_sample):
    import shap
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    import os

    trained_features = model.get_booster().feature_names
    X_aligned = X_sample.copy()

    for col in trained_features:
        if col not in X_aligned.columns:
            X_aligned[col] = 0
    X_aligned = X_aligned[trained_features]

    X_shap = X_aligned.sample(n=min(1000, len(X_aligned)), random_state=42)

    explainer = shap.Explainer(model, X_shap)
    shap_values = explainer(X_shap, check_additivity=False)

    os.makedirs("plots", exist_ok=True)
    shap.summary_plot(shap_values.values, X_shap, show=False)
    plt.title("SHAP Summary Plot (XGBoost)")
    plt.savefig("plots/shap_summary_xgb.png", bbox_inches="tight")
    plt.close()

    shap.summary_plot(shap_values.values, X_shap, plot_type="bar", show=False)
    plt.title("SHAP Feature Importance (XGBoost)")
    plt.savefig("plots/shap_bar_xgb.png", bbox_inches="tight")
    plt.close()

    print("✅ SHAP plots saved in 'plots/' folder as shap_summary_xgb.png and shap_bar_xgb.png.")

# ======================================
# 6️⃣ Main Execution (XGBoost Optimization & Training)
# ======================================
if __name__ == "__main__":
    import numpy as np
    import pandas as pd
    import os
    import matplotlib.pyplot as plt
    from sklearn.metrics import classification_report, roc_auc_score, f1_score, recall_score, precision_score

    SEED = 42

    print("\n🚀 Starting XGBoost Hyperparameter Optimization with Optuna...")

    # === 1. Tune Hyperparameters ===
    best_params = tune_hyperparameters(X_train_raw, y_train)

    # === 2. Train Final Model on full training data ===
    final_model = train_final_model(X_train_raw, y_train, best_params)

    # === 3. Evaluate Model ===
    preds_proba = final_model.predict_proba(X_test_raw)[:, 1]
    preds = (preds_proba > 0.5).astype(int)

    print("\n📊 Classification Report (XGBoost):")
    print(classification_report(y_test, preds))
    print(f"ROC-AUC: {roc_auc_score(y_test, preds_proba):.4f}")

    # === 4. Save Model ===
    MODEL_DIR = "models"
    os.makedirs(MODEL_DIR, exist_ok=True)
    model_path = os.path.join(MODEL_DIR, "xgb_fraud_model.json")
    final_model.save_model(model_path)
    print(f"💾 Model saved to {model_path}")

    # === 5. Explain Model with SHAP ===
    print("\n🔍 Generating SHAP explanations...")
    X_test_numeric = X_test_raw.select_dtypes(include=[np.number])
    explain_model(final_model, X_test_numeric)

    # === 6. Optional: Check Class Balance (Fraud Rate) ===
    fraud_rate_actual = y_test.mean()
    fraud_rate_predicted = preds.mean()
    print(f"\n🔹 Actual Fraud Rate: {fraud_rate_actual:.4f}")
    print(f"🔹 Predicted Fraud Rate: {fraud_rate_predicted:.4f}")


# ---------------------------------------------------------------
# 8️⃣ Balanced Training & Final XGBoost Model
# ---------------------------------------------------------------
import pandas as pd
from sklearn.utils import resample
from sklearn.metrics import classification_report, roc_auc_score, f1_score, recall_score, precision_score
import matplotlib.pyplot as plt
import numpy as np
import os

SEED = 42

print("\n⚖️ Rebalancing training data (overall class balancing)...")

# Önce X_train_raw ve y_train'ı birleştir
train_df = X_train_raw.copy()
train_df["target"] = y_train

# Eğer veri setinde kategorik kolonlar yoksa, kendi durumuna göre burayı değiştir
# Örn: gender ve country yoksa tek başına target kullanabiliriz
categorical_cols = [col for col in train_df.columns if train_df[col].dtype == "object"]
if not categorical_cols:
    categorical_cols = ["target"]  # tek grup

group_counts = train_df.groupby(categorical_cols).size()
print("\nGroup counts (before upsampling):")
print(group_counts)

max_count = group_counts.max()
upsampled_groups = []

for name, group_df in train_df.groupby(categorical_cols):
    if len(group_df) < max_count:
        group_up = resample(group_df, replace=True, n_samples=max_count, random_state=SEED)
        upsampled_groups.append(group_up)
    else:
        upsampled_groups.append(group_df)

train_balanced = pd.concat(upsampled_groups).sample(frac=1.0, random_state=SEED).reset_index(drop=True)

print("\nGroup counts (after upsampling):")
print(train_balanced.groupby(categorical_cols).size())

# Train-X ve y ayır
y_train_bal = train_balanced["target"]
X_train_bal = train_balanced.drop(["target"], axis=1)

# 🚀 1️⃣ Tune Hyperparameters on balanced data
print("\n🚀 Starting Optuna hyperparameter tuning on balanced training data...")
best_params_bal = tune_hyperparameters(X_train_bal, y_train_bal)

# 🚀 2️⃣ Train final model on balanced data
final_model_bal = train_final_model(X_train_bal, y_train_bal, best_params_bal)

# 🚀 3️⃣ Evaluate
preds_proba_bal = final_model_bal.predict_proba(X_test_raw)[:, 1]
preds_bal = (preds_proba_bal > 0.5).astype(int)

print("\n📊 Classification Report (Balanced XGBoost):")
print(classification_report(y_test, preds_bal))
print(f"ROC-AUC: {roc_auc_score(y_test, preds_proba_bal):.4f}")

# 🚀 4️⃣ Save model
MODEL_DIR = "models"
os.makedirs(MODEL_DIR, exist_ok=True)
model_path_bal = os.path.join(MODEL_DIR, "xgb_fraud_model_balanced.json")
final_model_bal.save_model(model_path_bal)
print(f"💾 Balanced model saved to {model_path_bal}")

# 🚀 5️⃣ SHAP explanations
print("\n🔍 Generating SHAP explanations for balanced model...")
X_test_numeric = X_test_raw.select_dtypes(include=[np.number])
explain_model(final_model_bal, X_test_numeric)

# 🚀 6️⃣ Optional: Check class balance
fraud_rate_pred_bal = preds_bal.mean()
print(f"\n🔹 Actual Fraud Rate: {y_test.mean():.4f}")
print(f"🔹 Predicted Fraud Rate (Balanced model): {fraud_rate_pred_bal:.4f}")

