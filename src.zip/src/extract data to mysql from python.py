# ---------------------------------------------------------------
# 🚀 MySQL Upload Script
# ---------------------------------------------------------------
import pandas as pd
from sqlalchemy import create_engine, text
from dotenv import load_dotenv
import os

# 1️⃣ Load environment variables from .env
load_dotenv()

# 2️⃣ Read database credentials from environment variables
DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_HOST = os.getenv("DB_HOST", "localhost")  # default localhost
DB_NAME = os.getenv("DB_NAME", "credit_card_fraud_db")

# 3️⃣ Create a secure MySQL connection
engine = create_engine(f"mysql+mysqlconnector://{DB_USER}:{DB_PASS}@{DB_HOST}/{DB_NAME}")

# 4️⃣ Read the CSV file
csv_path = "creditcard.csv"
df = pd.read_csv(csv_path)
num_rows_csv = len(df)
num_cols_csv = len(df.columns)

print(f"📥 CSV loaded successfully: {num_rows_csv} rows, {num_cols_csv} columns")

# 5️⃣ Clean up any previous connections
engine.dispose()

# 6️⃣ Upload the data to MySQL
table_name = "credit_card_fraud"
df.to_sql(table_name, con=engine, if_exists="replace", index=False, chunksize=1000)
print(f"💾 Uploading data into table '{table_name}'...")

# 7️⃣ Verify the data on the MySQL side
with engine.connect() as conn:
    num_rows_mysql = conn.execute(text(f"SELECT COUNT(*) FROM {table_name}")).scalar()
    result_cols = conn.execute(text(f"SELECT * FROM {table_name} LIMIT 1"))
    num_cols_mysql = len(result_cols.keys())

# 8️⃣ Compare and confirm
if num_rows_csv == num_rows_mysql and num_cols_csv == num_cols_mysql:
    print(f"✅ CSV successfully uploaded to MySQL! ({num_rows_mysql} rows, {num_cols_mysql} columns)")
else:
    print(
        f"⚠️ Data mismatch detected! "
        f"CSV: {num_rows_csv} rows, {num_cols_csv} columns | "
        f"MySQL: {num_rows_mysql} rows, {num_cols_mysql} columns"
    )


